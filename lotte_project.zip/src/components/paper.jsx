import React from "react";

const Paper = () => {
    return (
        <div>상품권이다</div>
    )
}

export default Paper;