import React from "react";
import styled from 'styled-components';

const FooterWrap = styled.div`
width: 100%;
height: 200px;
background: #1c1b1b;
color: #fff;
`


const Footer = () => {
    return (

        <FooterWrap>나는 푸터닫</FooterWrap>
    )
}

export default Footer;