import React from "react";

const MainContentsDetail = () => {
    return(
        <div>디테일페이지에요</div>
    )
}

export default MainContentsDetail;